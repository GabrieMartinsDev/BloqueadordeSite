import tkinter as tk
from tkinter import messagebox
import os
import platform

# Função para bloquear o site
def bloquear_site():
    site = entry_url.get()
    if site:
        # Caminho para o arquivo 'hosts' (variável de sistema)
        if platform.system() == "Windows":
            hosts_path = r"C:\Windows\System32\drivers\etc\hosts"
        else:
            hosts_path = "/etc/hosts"
        
        try:
            # Abrir o arquivo 'hosts' em modo de append
            with open(hosts_path, 'a') as file:
                # Adicionar a linha para bloquear o site
                file.write(f"\n127.0.0.1 {site}")
            messagebox.showinfo("Bloqueio Completo ⚠️", f"O site {site} foi agora BLOQUEADO com sucesso! 💀")
        except PermissionError:
            messagebox.showerror("Erro Fatal 💀", "Permissões insuficientes. Execute o programa como administrador.")
        except Exception as e:
            messagebox.showerror("Erro Fatal 💀", f"Erro ao bloquear o site: {str(e)}")
    else:
        messagebox.showwarning("Aviso Sombrio ⚠️", "Por favor, insira uma URL válida. O caos se aproxima!")

# Função para desbloquear o site
def desbloquear_site():
    site = entry_url.get()
    if site:
        if platform.system() == "Windows":
            hosts_path = r"C:\Windows\System32\drivers\etc\hosts"
        else:
            hosts_path = "/etc/hosts"
        
        try:
            # Abrir o arquivo 'hosts' para ler o conteúdo
            with open(hosts_path, 'r') as file:
                lines = file.readlines()
            
            # Filtrar as linhas removendo a linha com o site
            with open(hosts_path, 'w') as file:
                for line in lines:
                    if site not in line:
                        file.write(line)
            
            messagebox.showinfo("Desbloqueio Completo ⚡", f"O site {site} foi DESBLOQUEADO com sucesso! ⚡")
        except PermissionError:
            messagebox.showerror("Erro Fatal 💀", "Permissões insuficientes. Execute o programa como administrador.")
        except Exception as e:
            messagebox.showerror("Erro Fatal 💀", f"Erro ao desbloquear o site: {str(e)}")
    else:
        messagebox.showwarning("Aviso Sombrio ⚠️", "Por favor, insira uma URL válida. O caos se aproxima!")

# Função para mostrar todos os sites bloqueados e permitir desbloqueio múltiplo
def mostrar_sites_bloqueados():
    # Caminho para o arquivo 'hosts' (variável de sistema)
    if platform.system() == "Windows":
        hosts_path = r"C:\Windows\System32\drivers\etc\hosts"
    else:
        hosts_path = "/etc/hosts"

    try:
        # Ler o arquivo hosts
        with open(hosts_path, 'r') as file:
            lines = file.readlines()
        
        # Filtrar os sites bloqueados (linhas que começam com 127.0.0.1)
        blocked_sites = [line.split()[1] for line in lines if line.startswith("127.0.0.1")]
        
        if blocked_sites:
            # Criar uma nova janela para exibir os sites bloqueados
            janela_bloqueados = tk.Toplevel(root)
            janela_bloqueados.title("Sites Bloqueados 💀")
            janela_bloqueados.geometry("400x300")
            janela_bloqueados.configure(bg="#2e2e2e")
            
            # Adicionar uma lista de sites bloqueados para selecionar
            label_bloqueados = tk.Label(janela_bloqueados, text="Clique para DESBLOQUEAR os sites:", font=("Courier", 14), fg="white", bg="#2e2e2e")
            label_bloqueados.pack(pady=10)
            
            def desbloquear_selecionado():
                for site in blocked_sites_listbox.curselection():
                    site_to_remove = blocked_sites[site]
                    # Desbloquear o site selecionado
                    with open(hosts_path, 'r') as file:
                        lines = file.readlines()
                    with open(hosts_path, 'w') as file:
                        for line in lines:
                            if site_to_remove not in line:
                                file.write(line)
                    # Remover da lista
                    blocked_sites_listbox.delete(site)
                messagebox.showinfo("Desbloqueio Múltiplo ⚡", "Os sites selecionados foram desbloqueados com sucesso!")

            # Criar a listbox para exibir os sites bloqueados
            blocked_sites_listbox = tk.Listbox(janela_bloqueados, selectmode=tk.MULTIPLE, width=40, height=10, bg="#4b4b4b", fg="white", font=("Courier", 12), selectbackground="red", selectforeground="white")
            for site in blocked_sites:
                blocked_sites_listbox.insert(tk.END, site)
            blocked_sites_listbox.pack(pady=10)

            # Botão para desbloquear os sites selecionados
            button_desbloquear_selecionados = tk.Button(janela_bloqueados, text="Desbloquear Selecionados", font=("Courier", 12), bg="#ff3333", fg="white", command=desbloquear_selecionado, relief="solid", borderwidth=3)
            button_desbloquear_selecionados.pack(pady=10)

        else:
            messagebox.showinfo("Sem Sites Bloqueados ⚠️", "Não há sites bloqueados no momento. O caos ainda não se instaurou.")
    
    except Exception as e:
        messagebox.showerror("Erro Fatal 💀", f"Erro ao ler o arquivo de hosts: {str(e)}")

# Criando a janela principal
root = tk.Tk()
root.title("GMA Blocker 💀")  # Alterado para incluir o emoji de mal no título
root.geometry("400x300")
root.configure(bg="#2e2e2e")  # Cor de fundo escura (cinza muito escuro)

# Cabeçalho com fonte e cor agressiva
header = tk.Label(root, text="GMA Blocker 💀", font=("Impact", 20), fg="#FF3333", bg="#2e2e2e")  # Usando a fonte 'Impact' e uma cor vermelha agressiva
header.pack(pady=10)

# Campo para inserir a URL
label_url = tk.Label(root, text="Digite a URL do site:", font=("Arial", 12), fg="white", bg="#2e2e2e")
label_url.pack(pady=5)

entry_url = tk.Entry(root, font=("Arial", 12), width=30, bg="#4b4b4b", fg="white", borderwidth=2, relief="solid")
entry_url.pack(pady=10)

# Botões para bloquear, desbloquear e mostrar sites bloqueados com bordas agressivas
button_bloquear = tk.Button(root, text="Bloquear Site", font=("Courier", 14, "bold"), bg="#8b0000", fg="white", command=bloquear_site, relief="solid", borderwidth=3)
button_bloquear.pack(pady=10)

button_desbloquear = tk.Button(root, text="Desbloquear Site", font=("Courier", 14, "bold"), bg="#444444", fg="white", command=desbloquear_site, relief="solid", borderwidth=3)
button_desbloquear.pack(pady=10)

button_mostrar = tk.Button(root, text="Mostrar Sites Bloqueados", font=("Courier", 14, "bold"), bg="#ff3333", fg="white", command=mostrar_sites_bloqueados, relief="solid", borderwidth=3)
button_mostrar.pack(pady=10)

# Iniciar a interface
root.mainloop()
